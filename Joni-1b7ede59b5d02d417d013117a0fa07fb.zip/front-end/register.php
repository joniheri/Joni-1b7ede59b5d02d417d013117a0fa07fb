<!DOCTYPE html> 
<html lang="en"> 
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<div id="form_login" style="width:380px; height:160px;">
        <div id="log_head"><strong>REGISTER</strong></div>
        <div id="log_cont">
            <form action="../back-end/proses_registrasi.php" method="POST">
                <table width="100%" style="background:#FFF; ">
                    <tr>
                        <td>Username</td>
                        <td>:</td>
                        <td><input type="text" name="user" size="30%" required></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td>:</td>
                        <td><input type="password" name="pass" size="30%" required></td>
                    </tr>
                    <tr>
                        <td>Repeat Password</td>
                        <td>:</td>
                        <td><input type="password" name="repass" size="30%" required></td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td><button type="submit" name="log" value="LOGIN">REGISTER</button></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</body>
</html>