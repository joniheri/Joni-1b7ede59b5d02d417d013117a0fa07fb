<?php
session_start();
if(!isset($_SESSION['id'])){
	echo "<script>alert('Silahkan login terlebih dahulu')</script>";
	echo "<meta http-equiv='refresh' content='0; url=../index.php'>";
} else {
	include '../back-end/koneksi_mysqli.php';
	$username	= $_SESSION['id'];	
	$sql    	= mysqli_query($koneksi,"SELECT * FROM tbl_user where username='$username'");
	$data   	= mysqli_fetch_array($sql);
	$username   = $data['username'];
	$password   = $data['password'];
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<center>
		<form>
			<table width="500" id="isi_konten">
				<tr>
					<td>Hai</td>
					<td>:</td>
					<td><?php echo $username; ?></td>
				</tr>
				<tr>
					<td>Waktu Login</td>
					<td>:</td>
					<td><?php echo date('d-m-Y'); ?></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td><a href="../back-end/logout.php">Logout</a></td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
			</table>
		</form>
	</center>
</body>
</html>
<?php } ?>
