<?php
	/*
	session_start();
	if(!isset($_SESSION['nama'])){
		//echo "<script>alert('Silahkan login terlebih dahulu')</script>";
		echo "<meta http-equiv='refresh' content='0; url=index.php'>";
	} else {
	*/
	session_start();
	if(isset($_SESSION['id'])){
		echo "<script>alert('Anda sudah login.')</script>";
		echo "<meta http-equiv='refresh' content='0; url=setelah_login.php'>";
	} else {
?>
<!DOCTYPE html> 
<html lang="en"> 
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<div id="form_login" style="width:350px; height:160px;">
        <div id="log_head"><strong>LOGIN</strong></div>
        <div id="log_cont">
            <form action="../back-end/cek-login.php" method="POST">
                <table width="100%" style="background:#FFF; ">
                    <tr>
                        <td width="20%">Username</td>
                        <td>:</td>
                        <td><input type="text" name="user" size="30%" required></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td>:</td>
                        <td><input type="password" name="pass" size="30%" required></td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td><button type="submit" name="log" value="LOGIN">LOGIN</button> <a href="register.php" title="Jika ingin daftar baru">REGISTER</a></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</body>
</html>
<?php } ?>