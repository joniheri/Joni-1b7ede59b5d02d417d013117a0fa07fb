<?php
	include 'koneksi_mysqli.php';
	if(isset($_POST['log'])) {

		$user 	= $_POST['user'];
		$pass 	= $_POST['pass']; 
		$repass = $_POST['repass'];
		$pass_md5 	= md5($pass);
		//echo "Username : $user <br>Password : $pass <br>Password md5 : $pass_md5";
		if ($pass != $repass){
			echo "<script> alert('Tambah pelanggan BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=../front-end/register.php'>";
		}
		else{
			$sql_cek_duplikat	= mysqli_query($koneksi,"SELECT * FROM tbl_user where username='$user'");
			$data_cek_duplikat 	= mysqli_fetch_array($sql_cek_duplikat);
			$username_data 		= $data_cek_duplikat['username'];
			if ($user==$username_data) {
				echo "<script>alert('Username $user SUDAH ADA!');</script>";
				echo "<meta http-equiv='refresh' content='0; url=../front-end/register.php'>";
			}
			else {
				$input = mysqli_query($koneksi,"INSERT into tbl_user values(
					'$user',
					'$pass_md5'
				)");
				 
				if ($input) {
					echo "<script> alert('Regirster BERHASIL.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=../front-end/login.php'>";	
				}
				else {
					echo "<script> alert('Register GAGAL!') </script>";
					echo "<meta http-equiv='refresh' content='0; url=../front-end/register.php'>";	
				}
			}
		}
	}
?>