<?php
	include 'koneksi_mysqli.php';
	if(isset($_POST['log'])) {

		$user 	= mysqli_real_escape_string($koneksi,$_POST['user']);
		$pass 	= mysqli_real_escape_string($koneksi,$_POST['pass']); 
		$pass 	= md5($pass);
		$sql	= mysqli_query($koneksi,"SELECT * FROM tbl_user where username='$user' and password='$pass'");
		$data 	= mysqli_fetch_array($sql);

		$username 	= $data['username'];
		$password 	= $data['password'];
		
		if ($user==$username && $pass==$password) {
			session_start();
			$_SESSION['id']=$username;
			echo "<script>alert('Login BERHASIL!');</script>";
			echo "<meta http-equiv='refresh' content='0; url=../front-end/setelah_login.php'>";
		}
		else {
			echo "<script>alert('Username dan password anda salah, Silahkan login kembali !');</script>";
			echo "<meta http-equiv='refresh' content='0; url=index.php'>";
		}
	}
?>