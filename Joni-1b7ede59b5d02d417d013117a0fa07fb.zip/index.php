<!DOCTYPE html>
<html>
<head>
    <title>SELAMAT DATANG</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="front-end/style.css" />
</head>
<body>
    <center>
        <h1><?php include 'front-end/jam_digital.php'; ?></h1>
        <div id="tombol_login" ><a href="front-end/login.php">HALLO</a></div>
    </center>
</body>
</html>